# GUI with PyWebIO
Simple, fast, and with fewer errors
Only requires
```bash
pip install gpt4free
pip install pywebio
```
clicking on 'pywebio-usesless.py' will run it

PS: Currently, only 'usesless' is implemented, and the GUI is expected to be updated infrequently, with a focus on stability.

↓ Here is the introduction in zh-Hans-CN below.

# 使用pywebio实现的极简GUI
简单，快捷，报错少
只需要
```bash
pip install gpt4free
pip install pywebio
```

双击pywebio-usesless.py即可运行

ps：目前仅实现usesless，这个gui更新频率应该会比较少，目的是追求稳定
